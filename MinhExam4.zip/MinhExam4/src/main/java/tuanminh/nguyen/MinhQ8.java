package tuanminh.nguyen;
//Tuan Minh Nguyen N01250520
public class MinhQ8 {
    //i. Support different languages:
    //   1. Create another res/values/strings.xml file that supports another language ( locale )
    //   2. After you’ve decided on the locales to support, create the resource subdirectories and files
    //   3. You can reference the resources in your source code and other XML files using each resource's name attribute.

    //ii. Support 2 different layouts, landscape and vertical:
    //   1. Make different layouts for both smartphone and tablets
    //   2. Constraint the object in the xml file to fit with each layout

    //iii.Support tablet layout vs. smartphone lauout:
    //   1. Create alternative layouts
    //   2. Use the smallest width qualifier
    //   3. Use available width qualifier
    //   4. Add orientation qualifiers
    //   5. Modularize UI components with fragments
}
